using System;
using System.Threading;
class Program
{
    static void Main()
    {
        Random random = new Random();
        Console.WriteLine(" ");
        Console.WriteLine("hello! its pepsi_3.9.2_reborn_butC#");
        Console.WriteLine(" ");
        while (true)
        {

            Console.WriteLine("-menu-");
            Console.WriteLine("play");
            Console.WriteLine("change log");
            Console.WriteLine("github");
            Console.WriteLine("telegram");
            Console.WriteLine("credit");
            Console.WriteLine("exit");
            Console.WriteLine(" ");
            Console.Write("choose: ");
            string answer = Console.ReadLine()?.ToLower();
            if (answer == "play")
            {
                int number = random.Next(1, 100 + 1);
                Console.Clear();
                Console.WriteLine("goodluck");
                while (true)
                {
                    Console.Write("number?: ");
                    int guess = int.Parse(Console.ReadLine());
                    if (number < guess)
                    {
                        Console.WriteLine("nah, thats a lot");
                    }
                    else if (number > guess)
                    {
                        Console.WriteLine("nah, thats not enough");
                    }
                    else if (number == guess)
                    {
                        Console.WriteLine($"good job, your number is {number}");
                        Thread.Sleep(3000);
                        Console.Clear();
                        break;
                    }
                }
            }
            else if (answer == "change log")
            {
                Console.Clear();
                Console.WriteLine("pepsi_3.5_reborn_butC#:");
                Console.WriteLine("pepsi_3.5_reborn_butC# was exit");
                Console.WriteLine("pepsi_3.9_reborn_butC#:");
                Console.WriteLine("add 'Console.Clear();' into code");
                Console.WriteLine("pepsi_3.9.2_reborn_butC#:");
                Console.WriteLine("bug fix");
                Console.WriteLine(" ");

                Console.WriteLine("write 'ok' for continue: ");
                string answer2 = Console.ReadLine()?.ToLower();
                if (answer2 == "ok")
                {
                    Console.Clear();
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Next time write 'ok' pls");
                    Thread.Sleep(1000);
                    Console.WriteLine("Next time write 'ok' pls");
                    Thread.Sleep(1000);
                    Console.WriteLine("Next time write 'ok' pls");
                    Thread.Sleep(1000);
                    Console.Clear();
                }
            }
            else if (answer == "github")
            {
                Console.Clear();
                Console.WriteLine("https://github.com/mishkagumiberr-star");
                Thread.Sleep(2500);
                Console.Clear();
            }
            else if (answer == "telegram")
            {
                Console.Clear();
                Console.WriteLine("t.me/peshera_treta");
                Thread.Sleep(2500);
                Console.Clear();
            }
            else if (answer == "credit")
            {
                Console.Clear();
                Console.WriteLine("game by - tret_game");
                Thread.Sleep(2500);
                Console.Clear();
            }
            else if (answer == "exit")
            {
                Console.WriteLine("goodbye");
                Thread.Sleep(2000);
                return;
            }
            else
            {
                Console.WriteLine(" ");
                Console.WriteLine("i dont know what you say");
                Console.WriteLine(" ");
                Thread.Sleep(2000);
                Console.Clear();
            }
        }
    }
}
//так нет вкусности