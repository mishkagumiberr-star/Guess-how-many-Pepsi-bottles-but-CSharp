using System;
using System.Threading;
using System.IO;
class Program
{
    static void Main()
    {
        Random random = new Random();
        Console.WriteLine(" ");
        Console.WriteLine("hello! its pepsi_4.0_reborn_butC#");
        Console.WriteLine(" ");
        while (true)
        {

            Console.WriteLine("-menu-");
            Console.WriteLine("play");
            Console.WriteLine("change log");
            Console.WriteLine("github");
            Console.WriteLine("telegram");
            Console.WriteLine("opensource");
            Console.WriteLine("credit");
            Console.WriteLine("exit");
            Console.WriteLine(" ");
            Console.Write("choose: ");
            string answer = Console.ReadLine()?.ToLower();
            if (answer == "play")
            {
                int number = random.Next(1, 100 + 1);
                Console.Clear();
                Console.WriteLine("goodluck");
                while (true)
                {
                    Console.Write("number?: ");
                    int guess = int.Parse(Console.ReadLine());
                    if (number < guess)
                    {
                        Console.WriteLine("nah, thats a lot");
                    }
                    else if (number > guess)
                    {
                        Console.WriteLine("nah, thats not enough");
                    }
                    else if (number == guess)
                    {
                        Console.WriteLine($"good job, your number is {number}");
                        Thread.Sleep(3000);
                        Console.Clear();
                        break;
                    }
                }
            }
            else if (answer == "change log")
            {
                Console.Clear();
                Console.WriteLine("pepsi_3.5_reborn_butC#:");
                Console.WriteLine("pepsi_3.5_reborn_butC# was exit");
                Console.WriteLine("pepsi_3.9_reborn_butC#:");
                Console.WriteLine("add 'Console.Clear();' into code");
                Console.WriteLine("pepsi_3.9.2_reborn_butC#:");
                Console.WriteLine("bug fix");
                Console.WriteLine("pepsi_4.0_reborn_butC#:");
                Console.WriteLine("add 'System.IO'");
                Console.WriteLine(" ");
                Console.WriteLine("press any key");
                Console.ReadKey();
                Console.Clear();
            }
            else if (answer == "github")
            {
                Console.Clear();
                Console.WriteLine("https://github.com/mishkagumiberr-star");
                Thread.Sleep(2500);
                Console.Clear();
            }
            else if (answer == "telegram")
            {
                Console.Clear();
                Console.WriteLine("t.me/peshera_treta");
                Thread.Sleep(2500);
                Console.Clear();
            }
            else if (answer == "credit")
            {
                Console.Clear();
                Console.WriteLine("game by - tret_game");
                Thread.Sleep(2500);
                Console.Clear();
            }
            else if (answer == "exit")
            {
                Console.WriteLine("goodbye");
                Thread.Sleep(2000);
                return;
            }
            //финя для того чтобы я мог иметь доступ к исходнику, зачем? доступ к исходнику на любом устройстве
            else if (answer == "opensource")
            {
                string pepsi_reborn_opensorce = "pepsi_reborn_4.0CS.cs";

                if (File.Exists(pepsi_reborn_opensorce))
                {
                    Console.Clear();
                    string source = File.ReadAllText(pepsi_reborn_opensorce);
                    Console.WriteLine(source);
                    Console.ReadKey();
                    Console.Clear();
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("нету");
                    Thread.Sleep(1000);
                    Console.Clear();
                }
            }
            else
            {
                Console.WriteLine(" ");
                Console.WriteLine("i dont know what you say");
                Console.WriteLine(" ");
                Thread.Sleep(2000);
                Console.Clear();
            }
        }
    }
}
//дальше нет вкусности
